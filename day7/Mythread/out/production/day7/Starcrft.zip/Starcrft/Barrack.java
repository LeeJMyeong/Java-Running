package Starcrft;

public class Barrack extends Unit {
    Barrack barrack = new Barrack();

    public Barrack(int unit, int hp, int attack, int defend) {
        super(unit, hp, attack, defend);
    }
}
