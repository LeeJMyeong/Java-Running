package Starcrft;

public class Thread extends java.lang.Thread {


}
